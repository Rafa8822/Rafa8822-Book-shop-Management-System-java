package f_lab_01;


class StoryBook extends Book
{

	public String catagory;
	
	public StoryBook()
	{
		
	}
	
	public StoryBook(String Isbn,String bookTitle,String authorName,double price,int availableQuantity,String catagory)
	{
		
		super(Isbn,bookTitle,authorName,price, availableQuantity);
		this.catagory=catagory;
	}
	

	
	
	public void Set_catagory(String catagory)
	{
		this.catagory=catagory;
	}
	
	
	
	public String Get_catagory()
	{
		return this.catagory;
	}

	@Override //from abstruct class here implemented the body
	public void showDetails() {
		
		System.out.println("Book ISBN: "+ this.getIsbn());
		System.out.println("Book Title: "+ this.getBookTitle());
		System.out.println("Author Name: "+ this.getAuthorName());
		System.out.println("Book Price: "+ this.getPrice());
		System.out.println("Book's Current Quantitity: "+ this.getAvailableQuantity());
		System.out.println("--------------------------------");

		
	}
	
	
	
	
	
	
	
	
}
