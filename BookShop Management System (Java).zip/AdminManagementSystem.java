package f_lab_01;

import java.util.InputMismatchException;
import java.util.Scanner;

public class AdminManagementSystem extends Authentication 
	
{	Scanner input=new Scanner(System.in);
	


	private BookShop Myshop;
	private Start srtobj;
	
	
	public void setter(Start srtobj)
	{
		this.srtobj=srtobj;
	}
	
	public AdminManagementSystem(BookShop Myshop)
	{
		this.Myshop=Myshop;
		
		
	}
	
	public void repeted()
	{
		System.out.print("Do u want other operation?(y/n )");
		String choice = input.next().toLowerCase();
		if(choice.equals("y"))
		{
			this.AdminMenue();
		}
		else if(choice.equals("n"))
		{
			System.out.print("************Thank you for using************");
			System.exit(1);
			
		}
		else
		{
			System.out.print("Invalid.....");
			this.repeted();
		}
		
	}
	
	public void AdminMenue ()
	{
		

		  System.out.println("1.Show All Books\n2.Search Book\n3.Add Book\n4.Remove Book\n5.Logout");
		  		
		
		  System.out.print("Please Select 1 or 5: ");
		  String choice = input.next();
			
		  
		switch(choice)
		{
			case "1": this.Myshop.ShowAllBooks(); 
					this.repeted();
					
		    break;
		  
			case "2": 
			
			  System.out.print("Please Provide ISBN:");
			  String p= input.next().toString().trim();
			
			  this.Myshop.SearchBook(p);
			  this.repeted();
			  
		    break;
		    
			case "3": 
				
				System.out.print("1.StoryBook  2.TextBook ?");
			
				String data=input.next().toString().trim();
				
					switch(data)
					{
					case "1":
					System.out.print("\nSet ISBAN: ");
					String isbn=input.next().toString().toUpperCase().trim();
					 
					System.out.print("\nSet Book Title: ");
					String BookTitle=input.next().toString().trim();
					
					System.out.print("\nSet Authore Name: ");
					String AuthName=input.next().toString().trim();
					 
					System.out.print("\nSet Price: ");
					double price=input.nextDouble();
					
					System.out.print("\nSet Quantity: ");
					int quantity=input.nextInt();
					
					System.out.print("\nSet Catagory: ");
					String catgory=input.next().toString().trim();
					
					Book Story =new StoryBook(isbn,BookTitle,AuthName,price,quantity,catgory);
					
					if(this.Myshop.InseartBook(Story)==true)
					{
						System.out.print("Book Inseated successfully");
						this.repeted();
					}
					else
					{
						System.out.print("not insearted!!!!");
						this.AdminMenue();
					}
					
					
					break;
					
					case "2":
					System.out.print("\nSet ISBAN: ");
					String isbnn=input.next().toString().toUpperCase().trim();
					 
					System.out.print("\nSet Book Title: ");
					String BookTitlee=input.next().toString().trim();
					
					System.out.print("\nSet Authore Name: ");
					String AuthNamee=input.next().toString().trim();
					 
					System.out.print("\nSet Price: ");
					double pricee=input.nextDouble();
				
					 
					
					System.out.print("\nSet Quantity: ");
					int quantityy=input.nextInt();
					
	
					System.out.print("\nSet Catagory (1 to 10): ");
					int standard=input.nextInt();
					
					
					
					Book Text =new TextBook(isbnn,BookTitlee,AuthNamee,pricee,quantityy,standard);
					
					if(this.Myshop.InseartBook(Text)==true)
					{
						System.out.print("Book Inseated successfully");
						this.repeted();
					}
					else
					{
						System.out.print("not insearted!!!!");
						this.AdminMenue();
					}
					
					break;
					
					default:
						System.out.print("Invalid key word....");
						this.AdminMenue();
					
					}
				
			    break;
		  
			    
			case "4":
				 System.out.print("Please Provide ISBN:");
				 String remv= input.next().toString().trim();
				 
				 
				 if(this.Myshop.RemoveBook(remv)==false)
				 {
					 System.out.print("Successfully removed....  ");
					 this.repeted();
				 }
				 else
				 {
					 System.out.print("Not removed......  ");
					
						this.repeted();
				 }
				  
			    break;
			
			    
			
			case "5": 
				
				String x=srtobj.MainMenue(); 
				srtobj.menuCotroller(x);
				
			    break;
		  
			
			default:
			  	System.out.println("Invalid keyword...");
				  this.AdminMenue();
		}
		
		
	}
	
	
	
	
	
	
}
	
	
	

	
	
	

