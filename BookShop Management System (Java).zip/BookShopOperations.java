package f_lab_01;

public interface BookShopOperations {


	public boolean InseartBook(Book b);
	
	public boolean RemoveBook(String isbn);
	
	
	
	public void ShowAllBooks();
	
	public Book SearchBook (String isbn);


}
