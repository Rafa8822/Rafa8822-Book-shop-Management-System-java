package f_lab_01;
import java.util.Scanner;

public class UserManagentSystem {

	Scanner input = new Scanner(System.in);
	
	public BookShop Myshop;
	
	
	public UserManagentSystem (BookShop Myshop)
	{	
		this.Myshop=Myshop;
		
	}
	

	public void repeted()
	{
		System.out.print("  **Do u want other operation?(y/n )**");
		String choice = input.next().toLowerCase();
		if(choice.equals("y"))
		{
			this.UserMenu();
		}
		else
		{
			System.out.print("Thank you for using ");
			try {
				Thread.sleep(5000);
				
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	public void UserMenu()
	{
		
		
		  System.out.println("1.Show All Books\n2.Search Book\n3.Buy Book\n4.Exit");
		
		
		  
		  System.out.print("Please Select 1 to 4: ");
		  String choice = input.next().toString().trim();
		
		  
		switch(choice)
		{
			case "1": this.Myshop.ShowAllBooks(); 
					this.repeted();
					
		    break;
		  
			case "2": 
			
			  System.out.print("Please Provide ISBN:");
			  String p= input.next().toString().trim();
			
			  this.Myshop.SearchBook(p);
			  this.repeted();
			  
		    break;
		  
		    
			case "3": 
				
				  System.out.print("To Buy Please Provide ISBN:");
				  String isbn= input.next().toString().trim();
				
				  Book type=this.Myshop.SearchBook(isbn);
				  
				  if(type!=null)
				  {
					  System.out.print("How many Copy u want to buy?");
					  int copy= input.nextInt();
					  
					  if(type.getAvailableQuantity()>0 && type.getAvailableQuantity()>=copy)
					  { 
						 
						  int availble=type.getAvailableQuantity()-copy;
						  type.setAvailableQuantity(availble);
						  System.out.print("Total cost= ("+copy+ " X " + type.getPrice()+")  --->> "+ copy*type.getPrice()+" " );  
					  }
					  else
					  {
						  System.out.print("Sorry not much quantity");
					  }
					  
					  
				  }
				  
				  else
				  {
					  
					  System.out.print("No books available");
					  
				  }
				  
				  this.repeted();
				  
			    break;
			    
				case "4": 
					System.exit(1);
				
				break;			    
			    
				default:
			    
				System.out.println("Invalid key word....");
				UserMenu();
		
		}
		
		
		
	}





}







