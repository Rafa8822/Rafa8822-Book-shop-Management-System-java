package f_lab_01;

public class BookShop implements BookShopOperations  {

	private String name;
	
	public Book [] listOfBooks=new Book [100];
	
	
	

	public BookShop()
	{
		
	}
	
	public BookShop(String name)
	{
		this.name=name;
		
	}
	public void SetName(String name)
	{
		this.name=name;
	}
	public String GetName()
	{
		return this.name;
	}

	
	
	@Override //from Interface
	public boolean InseartBook(Book b) {
		
		boolean result=false;
		
		for(int i=0;i<this.listOfBooks.length;i++)
		{
			if(listOfBooks[i]==null)
			{
				listOfBooks[i]=b;
				result=true;
				break;
			}
			
			else
			{
				result=false;
			}

		}
		
				 
		return result; 
			
		
	}
	
	

	@Override //from Interface
	public boolean RemoveBook(String isbn) {
		
		boolean result=false;
		
		Book Remove_book = null;
		 
		for(int i=0;i<this.listOfBooks.length;i++)
		{	
			if(listOfBooks[i]!=null && listOfBooks[i].getIsbn().equals(isbn))
			{
				Remove_book=listOfBooks[i];
				break;
			}
			
			else
			{	Remove_book=null;
				continue;
			}
		}
		
		
		if(Remove_book!=null)
		{	
			for(int i=0;i<listOfBooks.length;i++)
			{
				if(listOfBooks[i]==Remove_book)
				{	
					int j=i;
					while(listOfBooks[j]!=null)
					{
						listOfBooks[j]=listOfBooks[j+1];
						j++;
					}
				}
			}
			
			
		}
		else
		{
			System.out.println("Book is not the list");
		}
		
		
		return result;
	
	}
	
	

	@Override  //from Interface
	public void ShowAllBooks()
	{
		
		
		for(int i=0;i<this.listOfBooks.length;i++)
			{
					if(listOfBooks[i]==null)
					{
						continue;
						
					}
					else
					{
						listOfBooks[i].showDetails();
			
					}	
			}
		
		
	}


	public String test(String a,String b)
	{
		if(a.equals(b))
		{
			System.out.print("EQUALS");
			return a;
		}
		else
		{
			System.out.print("NOT EQUALS");
			return null;
		}
	}
	
	
	
	@Override  //from Interface
	public Book SearchBook(String isbn) {
	
	
	
		Book result = null;
		
		for(int i=0;i<this.listOfBooks.length;i++)
				
		{	
			
			
			if(this.listOfBooks[i]!=null && this.listOfBooks[i].getIsbn().equals(isbn))
			{
			
				result=this.listOfBooks[i];
					
				break;
			}
			
			else
			{	result=null;
				continue;
			}
		}
		
		
		if(result==null)
		{
			System.out.println("Search output:--->>  "+isbn+" Book is not Found!!!!\n");
			
		}
		else
		{
			System.out.println("Search output:--->> "+isbn+ " Book is Found!!!!\n");
			result.showDetails();
		}
//	
		return result;
	
	}
	
	
	
	
/*	
	public boolean Inseart_Textbook(TextBook textbook_obj)
	{	
		boolean result=false;
		
		for(int i=0;i<this.textbooks.length;i++)
		{
			if(textbooks[i]==null)
			{
				textbooks[i]=textbook_obj;
				result=true;
				break;
			}

		}
		return result;
	}
	

	public boolean Remove_Textbook(TextBook textbook_obj)
	{	
		boolean result=false;
		
		for(int i=0;i<this.textbooks.length;i++)
		{
			if(textbooks[i].getAuthorName() == textbook_obj.getAuthorName())
			{
				textbooks[i]=null;
				result=true;
				break;
			}
			else
			{
				result=false;
				continue;
				
				
			}

		}
		return result;
	}
	
	
	public TextBook TextBook_Search(String isbn)
	{
		 TextBook result = null;
		 
			for(int i=0;i<this.textbooks.length;i++)
			{	
				if(textbooks[i]!=null && textbooks[i].getIsbn() == isbn)
				{
					//System.out.println("The book has found!!");
					result=textbooks[i];
					break;
				}
				
				else
				{	result=null;
					continue;
				}
			}
			
			
			if(result==null)
			{
				System.out.println("Book is not Found!!!!\n");
			}
			else
			{
				System.out.println("Book is  Found!!!!\n");
			}
		
			return result;
		
		
	}
	
	
	public void Show_AllTextBooks()
	{	
		//TextBook counter=null;
		
		for(int i=0;i<this.textbooks.length;i++)
		{
				if(textbooks[i]==null)
				{
					continue;
					
				}
				else
				{
					textbooks[i].showDetails();	
				}
			        
			
		}
	}
	







//************************Storybook***********************
	
	public boolean Inseart_Storybook(StoryBook storybook_obj)
	{	
		boolean result=false;
		
		for(int i=0;i<this.storybooks.length;i++)
		{
			if(storybooks[i]==null)
			{
				storybooks[i]=storybook_obj;
				result=true;
				break;
			}

		}
		return result;
	}
	

	public boolean Remove_Storybook(StoryBook storybook_obj)
	{	
		boolean result=false;
		
		for(int i=0;i<this.storybooks.length;i++)
		{
			if(storybooks[i].getAuthorName() == storybook_obj.getAuthorName())
			{
				storybooks[i]=null;
				result=true;
				break;
			}
			else
			{
				result=false;
				continue;
				
				
			}

		}
		return result;
	}
	
	
	public StoryBook StoryBook_Search(String isbn)
	{
		 StoryBook result = null;
		 
			for(int i=0;i<this.storybooks.length;i++)
			{	
				if(storybooks[i]!=null && storybooks[i].getIsbn() == isbn)
				{
					//System.out.println("The book has found!!");
					result=storybooks[i];
					break;
				}
				
				else
				{	result=null;
					continue;
				}
			}
			
			
			if(result==null)
			{
				System.out.println("Book is not Found!!!!\n");
			}
			else
			{
				System.out.println("Book is  Found!!!!\n");
			}
		
			return result;
		
		
	}
	
	
	public void Show_AllStoryBooks()
	{	
		//TextBook counter=null;
		
		for(int i=0;i<this.storybooks.length;i++)
		{
				if(storybooks[i]==null)
				{
					continue;
					
				}
				else
				{
					storybooks[i].showDetails();	
				}
			        
			
		}
	}


*/





	
	
	
	
	
	
	
	


}
