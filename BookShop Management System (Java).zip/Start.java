package f_lab_01;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class  Start {
	
	
	private UserManagentSystem userobj;
	private AdminManagementSystem adobj;
	
	public Start()
	{
		
	}
	public Start(UserManagentSystem userobj,AdminManagementSystem adobj)
	{
		this.userobj=userobj;
		this.adobj=adobj;
		
		
	}
	
	public void menuCotroller(String data)
	{
		

		if(data.equals("1"))
		{
		
		userobj.UserMenu();
		
			
		}
		else if(data.equals("2"))
		{
		
		boolean res= adobj.Admin_Login();
		
		
		if(res==true)
		{
			adobj.AdminMenue();
		}
		else
		{
			data="2";
			this.menuCotroller(data);
			
		}
		
		}
		else
		{
			System.out.print("\nInvalid key word......");
		}
		
	}
	
	public String MainMenue()
	{	
		String result=null;
		
		System.out.print("1. Simple User  2.Admin ");
		Scanner input=new Scanner(System.in);
		
		String data=input.next().toString().trim();
		
		if(data.equals("1"))
		{
			result="1";
			
		}
		else if(data.equals("2"))
		{   
			result="2";
			
		}
		else
		{
			System.out.println("Invalid k�y word....");
			
			this.MainMenue();
		}
		
		return result;
		
	}
	
	public static void main(String[] args) throws IOException {
		
		
		
		BookShop Myshop=new BookShop();
		
		Myshop.SetName("CLASSIC BOOK SHOP");
		System.out.println("\n          WELCOME TO "+Myshop.GetName() );
		System.out.println("\n********************************\n");
			
		
		
		//Object ONE for StoryBook*******************
		StoryBook Tamanna_StoryBook_01=new StoryBook
				(
				"#3DAC-152-1",
				"Harry Poter",
				"JK Rowulling",
				255.50,
				32,
				"StoryBook"				
				);
		
		StoryBook Tamanna_StoryBook_02=new StoryBook();
		
		Tamanna_StoryBook_02.setIsbn("#8GDH-122-1");
		Tamanna_StoryBook_02.setBookTitle("Robinson Cruso");
		Tamanna_StoryBook_02.setAuthorName("Daniyal Difo");
		Tamanna_StoryBook_02.setPrice(150.66);
		Tamanna_StoryBook_02.Set_catagory("Story Book");
		Tamanna_StoryBook_02.setAvailableQuantity(40);
		
		
		StoryBook Tamanna_StoryBook_03=new StoryBook
				(
				"#3DAC-112-1",
				"Micky han",
				"Twikles",
				205.50,
				12,
				"StoryBook"				
				);
		
		StoryBook Tamanna_StoryBook_04=new StoryBook
				(
				"#UQAC-152-1",
				"Spider Man",
				"Marvels",
				50.50,
				12,
				"StoryBook"				
				);
		
		StoryBook Tamanna_StoryBook_05=new StoryBook
				(
				"#TYAC-852-8",
				"Thor",
				"Marvels",
				120.50,
				12,
				"StoryBook"				
				);
		
	
		TextBook Tamanna_TextBook_01=new TextBook
				(
						"#8NHJ-112-5",
						"Electronic Devices",
						"Boris Jonshon",
						805.50,
						20,
						1
				);
		
		TextBook Tamanna_TextBook_02=new TextBook();
		
		Tamanna_TextBook_02.setIsbn("#3KZE-322-6");
		Tamanna_TextBook_02.setBookTitle("Basic Java");
		Tamanna_TextBook_02.setAuthorName("Oracle");
		Tamanna_TextBook_02.setPrice(850.66);
		Tamanna_TextBook_02.set_standard(2);
		Tamanna_TextBook_02.setAvailableQuantity(30);
		
		TextBook Tamanna_TextBook_03=new TextBook
				(
						"#9NHJ-912-2",
						"Operating Systems",
						"Lionaro fench",
						77.50,
						10,
						1
				);
		
		TextBook Tamanna_TextBook_04=new TextBook
				(
						"#879J-212-5",
						"Computer Graphics",
						"Shokyseches",
						85.57,
						20,
						1
				);
		
		TextBook Tamanna_TextBook_05=new TextBook
				(
						"#00HJ-812-9",
						"Accounting",
						"Mr.Stvevs",
						82.41,
						20,
						1
				);
		
		TextBook Tamanna_TextBook_06=new TextBook
				(
						"#00HJ-812-9xxxxx",
						"Accounting",
						"Mr.Stvevs",
						82.41,
						20,
						1
				);

			
		Myshop.InseartBook(Tamanna_TextBook_01);
		Myshop.InseartBook(Tamanna_TextBook_02);
		Myshop.InseartBook(Tamanna_TextBook_03);
		Myshop.InseartBook(Tamanna_TextBook_04);
		Myshop.InseartBook(Tamanna_TextBook_05);
		
		
		Myshop.InseartBook(Tamanna_StoryBook_01);
		Myshop.InseartBook(Tamanna_StoryBook_02);
		Myshop.InseartBook(Tamanna_StoryBook_03);
		Myshop.InseartBook(Tamanna_StoryBook_04);
		Myshop.InseartBook(Tamanna_StoryBook_05);
		

		UserManagentSystem userobj= new UserManagentSystem(Myshop);
		AdminManagementSystem adobj=new AdminManagementSystem(Myshop);
		
		Start obj=new Start(userobj,adobj);
		adobj.setter(obj);
		
		String x= obj.MainMenue();
		obj.menuCotroller(x);
		
		
		
			
		
		

	
	}

}
