package f_lab_01;

class TextBook extends Book {

	private int standard;
	
	public TextBook()
	{
		
	}
	public TextBook(String Isbn,String bookTitle,String authorName,double price,int availableQuantity, int standard)
	{
		super(Isbn,bookTitle,authorName,price,availableQuantity);
		this.standard=standard;
	}
	
	public void set_standard(int standard)
	{
		this.standard=standard;
	}
	
	public int get_standrd()
	{
		return this.standard;
	}
	
	

	@Override //from abstruct class implementation 
	
	public void showDetails()
	{
		System.out.println("Book ISBN: "+ this.getIsbn());
		

		System.out.println("Book Title: "+ this.getBookTitle());
		System.out.println("Author Name: "+ this.getAuthorName());
		System.out.println("Book Price: "+ this.getPrice());
		System.out.println("Book's Current Quantitity: "+ this.getAvailableQuantity());
		System.out.println("--------------------------------");

		
	}
	
	
	
}
