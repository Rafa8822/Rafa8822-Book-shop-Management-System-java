package f_lab_01;

import java.io.Console;
import java.util.Scanner;
import java.util.Arrays;
public class Authentication {


	private static String User_Name="admin";
	private static String password="admin";
//	
//	
	public boolean Admin_Login()
	{
		Scanner input= new Scanner(System.in);
		
		System.out.print("User Name: ");
	
		String name=input.next().trim();
		
		
		System.out.print("User Password: ");
		String pass=input.next().trim();
		
		
		if(Authentication.User_Name.equals(User_Name) && Authentication.password.equals(pass))
		{
			
			return true;
		}
		
		else
		{	
			System.out.print("\nInvalid Password or Name......\n");
		
			return false;
		}
		
				 
		
	}
	
	




}
