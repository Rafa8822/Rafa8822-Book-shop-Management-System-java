package f_lab_01;





public interface BookOperations
{

	public void add_Quantity(int ammount);
	public void sell_Quantity(int ammount);
	
	
	
	
	
	
}
