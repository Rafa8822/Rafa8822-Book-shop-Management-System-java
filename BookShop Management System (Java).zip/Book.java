
package f_lab_01;


public abstract class Book implements BookOperations {


private String Isbn;
private String bookTitle;
private String authorName;
private double price;
private int availableQuantity;


@Override //from interface
public void sell_Quantity(int ammount)
{
	
	if(ammount>=0 && this.availableQuantity>=ammount )
	{
		this.availableQuantity=this.availableQuantity-ammount;
	}
	else if(ammount>this.availableQuantity || this.availableQuantity==0)
	{
		System.out.println("Not Enough Quantity to sell!!!!!");
	}
	else
	{
		System.out.println("Invalid Sell Quantity.....");
	}
	
}


@Override  //from interface
public void add_Quantity(int ammount) {
	
	if(ammount>=0)
	{
		this.availableQuantity=this.availableQuantity+ammount;
	}
	else
	{
		System.out.println("Invalid Add Quantity.....");
	}
	
}





public Book()
{
	
}

public Book(String Isbn,String bookTitle,String authorName,double price,int availableQuantity)
{
	this.Isbn=Isbn;
	this.bookTitle=bookTitle;
	this.authorName=authorName;
	this.price=price;
	this.availableQuantity=availableQuantity;
	
	
}


//----------- Set methods/////
public void setIsbn(String Isbn)
{
	this.Isbn=Isbn;
}

public void setBookTitle(String bookTitle )
{
	this.bookTitle=bookTitle;
}

public void setAuthorName(String authorName)
{
	this.authorName=authorName;
}

public void setPrice(double price)
{
	this.price=price;
}

public void setAvailableQuantity(int availableQuantity)
{
	this.availableQuantity=availableQuantity;
}

//Get methods/---------------


public String getIsbn()
{
	return this.Isbn;
}

public String getBookTitle()
{
	return this.bookTitle;
}

public String getAuthorName()
{
	return this.authorName;
}

public double getPrice()
{
	return this.price;
}

public int getAvailableQuantity()
{	
	if(this.availableQuantity>0)
	{
		return this.availableQuantity;
	}
	else
	{
		return 0;
	}
	
}


//public void addQuantity(int ammount)
//{
//	this.availableQuantity=this.availableQuantity + ammount;
//}
//
//public void sellQuantity(int ammount)
//{
//	this.availableQuantity=this.availableQuantity - ammount;
//}



public abstract void showDetails();
	
		
//		System.out.println("Book ISBN: "+ this.getIsbn());
//		
//	
//		System.out.println("Book Title: "+ this.getBookTitle());
//		System.out.println("Author Name: "+ this.getAuthorName());
//		System.out.println("Book Price: "+ this.getPrice());
//		System.out.println("Book's Current Quantitity: "+ this.getAvailableQuantity());
//		System.out.println("--------------------------------");
//		
	
	
	





}
